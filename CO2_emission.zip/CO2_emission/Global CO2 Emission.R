#install packages
install.packages("readr")
install.packages("VIM")
install.packages("corrplot")

#Load necessary libraries
library(readr)  
library(dplyr)
library(VIM)
library(corrplot)
library(tseries)
library(forecast)
library(ggplot2) 


#Load the dataset
co2_data <- read_csv("https://raw.githubusercontent.com/owid/co2-data/master/owid-co2-data.csv")
head(co2_data)

#Check for missing values
missing_summary <- colSums(is.na(co2_data))
print("Missing Values Summary:")
print(missing_summary)

#handling missing values -numerical
#filling the null value columns with the mean value
co2_data <- co2_data %>%
  mutate(across(where(is.numeric), ~ ifelse(is.na(.), mean(., na.rm = TRUE), .)))
head(co2_data)

#handling missing values - categorical
#checking if it suitable to use kNN imputation for this data set
#1
sapply(co2_data, function(x) sum(is.na(x)) / length(x) * 100)
#percentage is less than 25% and only one categorical column is remaining with null values

#2
#Visualize missing value pattern
aggr_plot <- aggr(co2_data, col = c('navyblue', 'red'),
                  numbers = TRUE, sortVars = TRUE,
                  labels = names(co2_data), cex.axis = 0.7,
                  gap = 3, ylab = c("Missing Data", "Pattern"))
#Good for KNN if The missing values are not too clustered or random.
  
  
#since there is only one categorical column and it is not much important for the time series analysis 
#we can keep it as it is in the data set
#fill with mode of KNN is not suitable for that kind of column as well
#we can move it to as the last column of the data set for aviod the distraction from it
co2_data <- co2_data %>%
  relocate(iso_code, .after = last_col())
head(co2_data)

#Analyse co2 emission globally throught the years

#step 1
#Group global data by year (sum of CO2 if data is by country)
global_co2 <- co2_data %>%
  group_by(year) %>%
  summarise(global_co2 = sum(co2, na.rm = TRUE))
print(global_co2)

#step 2
#convert to time series 
global_ts <- ts(global_co2$global_co2, start = min(global_co2$year), frequency = 1)

#step 3
#Visualize Trend & Seasonality
plot(global_ts, main = "Global CO2 Emissions Over Time", ylab = "CO2 Emissions", xlab = "Year")

#Analyse co2 emission in Sri Lanka throught the years

#step 1
#filter data for sri lanka
sl_data <- co2_data %>% filter(country == "Sri Lanka")

#step 2
#convert to time series
sl_ts <- ts(sl_data$co2, start = min(sl_data$year), frequency = 1)

#step 3
#Plot Sri Lanka's CO2 trends and seasonality
plot(sl_ts, main = "Sri Lanka CO2 Emissions", ylab = "CO2 Emissions", xlab = "Year")

#step 4
#Use Augmented Dickey-Fuller (ADF) test to check for stationarity
adf.test(sl_ts)
#since p-value(0.5448) > 0.05 , data is non-stationary, then apply differencing

#step 5
#Apply differencing
diff_sl_ts <- diff(sl_ts)
plot(diff_sl_ts)
adf.test(diff_sl_ts)

#step 6
#plot acf and pacf plots
acf(diff_sl_ts)
pacf(diff_sl_ts)

#step 7
#Use auto.arima to find the best model
model <- auto.arima(sl_ts)
summary(model)

#step 8
#forecast values
forecast_vals <- forecast(model, h = 10)
plot(forecast_vals)

#fit arima model for the original dataset
model <- auto.arima(global_ts)

# Forecast next 6 years
fcast <- forecast(model, h = 6)

# Plot original time series with forecast
plot(global_ts,
     xlim = c(start(global_ts)[1], end(global_ts)[1] + 6),
     ylim = range(c(global_ts, fcast$upper, fcast$lower)),
     main = "Actual Data and Forecasted Data",
     xlab = "Year", ylab = "CO2 Emissions",
     col = "blue", lwd = 2)

# Forecast line
lines(fcast$mean, col = "red", lwd = 2)

# 95% CI shaded area
polygon(c(time(fcast$mean), rev(time(fcast$mean))),
        c(fcast$lower[,2], rev(fcast$upper[,2])),
        col = adjustcolor("red", alpha.f = 0.2), border = NA)

# 80% CI shaded area
polygon(c(time(fcast$mean), rev(time(fcast$mean))),
        c(fcast$lower[,1], rev(fcast$upper[,1])),
        col = adjustcolor("red", alpha.f = 0.1), border = NA)

# Legend
legend("topleft", legend = c("Actual Data", "Forecast", "80% CI", "95% CI"),
       col = c("blue", "red", "red", "red"), lwd = 2,
       fill = c(NA, NA, adjustcolor("red", alpha.f = 0.1), adjustcolor("red", alpha.f = 0.2)),
       border = NA, bty = "n")

#with the global co2 emission forcasting we can see an increasing pattern which can be a challenging problem in future

#fit arima model for the data related to Sri Lanka 
sl_model <- auto.arima(sl_ts)
sl_fcast <- forecast(sl_model, h = 6)

plot(sl_ts,
     xlim = c(start(sl_ts)[1], end(sl_ts)[1] + 6),
     ylim = range(c(sl_ts, sl_fcast$upper, sl_fcast$lower)),
     main = "Sri Lanka CO2 Emissions Forecast",
     xlab = "Year", ylab = "CO2 Emissions",
     col = "blue", lwd = 2)

# Forecast line
lines(sl_fcast$mean, col = "red", lwd = 2)

# 95% CI
polygon(c(time(sl_fcast$mean), rev(time(sl_fcast$mean))),
        c(sl_fcast$lower[,2], rev(sl_fcast$upper[,2])),
        col = adjustcolor("red", alpha.f = 0.2), border = NA)

# 80% CI
polygon(c(time(sl_fcast$mean), rev(time(sl_fcast$mean))),
        c(sl_fcast$lower[,1], rev(sl_fcast$upper[,1])),
        col = adjustcolor("red", alpha.f = 0.1), border = NA)

# Legend
legend("topleft", legend = c("Actual Data", "Forecast", "80% CI", "95% CI"),
       col = c("blue", "red", "red", "red"), lwd = 2,
       fill = c(NA, NA, adjustcolor("red", alpha.f = 0.1), adjustcolor("red", alpha.f = 0.2)),
       border = NA, bty = "n")
#with the sri lankan co2 emission forcasting we can see a decreasing trend which means with the time the co2 emission from various sources has been reduced in sri lanka
